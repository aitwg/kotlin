package com.mydomain.tetris.constants

enum class CellConstants(val value: Byte) {
    EMPTY(0), EPHEMERAL(1)
}