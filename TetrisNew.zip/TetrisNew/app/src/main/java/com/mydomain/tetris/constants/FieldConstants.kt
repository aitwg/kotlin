package com.mydomain.tetris.constants

enum class FieldConstants(val value: Int) {
    COLUMN_COUNT(10), ROW_COUNT(20)
}